import { ID } from "appwrite"
import { storage } from "./appwrite"


console.log("hello there")
const files  = document.getElementById('fileInput') as HTMLInputElement
const btn = document.getElementById('btn') as HTMLButtonElement
btn.addEventListener('click',()=>{
  if(files.type ==='file' && files.files && files.files.length > 0) 
  storage.createFile('65cccfa21ee3345cbbf2',ID.unique(),files.files[0])
  .then(res=>console.log(res))
  .catch(err=>console.log(err)) 
  else console.log("No file found")
})
// AUTHORISATION AND AUTHENTICATION
const (Account,Client,ID) = require("appwrite")
const client = new Client().setEndpoint('http://localhost/v1').setProject('')
const account = new Account(client)

async function run(){
    try{
        const res =await account.create(ID.unique().'val@gmail.com','123456','valleri')
        console.log(res);
    }catch(error){
        console.log(error)
    }
}

run()